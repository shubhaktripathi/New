import {LightningElement, api, wire, track} from 'lwc';
import getAccount from '@salesforce/apex/AccountHandler.getAccount';
import updateAccount from '@salesforce/apex/AccountHandler.updateAccount';

export default class AccountQuickUpdateApex extends LightningElement {
  @api recordId;
  @track acc = {
    name: '',
    phone: '',
    website: '',
  };

  @wire (getAccount, {recordId: '$recordId'})
  accList({error, data}) {
    if (data) {
      console.log ('Data', data);
      this.acc.name = data.Name;
      this.acc.website = data.website;
      this.acc.phone = data.Phone;
      console.log ('acc is' + JSON.stringify (this.acc));
    } else if (error) {
      console.error ('Error:', error);
    }
  }

  changeHandler (event) {
    if (event.target.name === 'Name') {
      this.acc.name = event.target.value;
      console.log ('name is' + this.acc.name);
    } else if (event.target.name === 'website') {
      this.acc.website = event.target.value;
    } else if (event.target.name === 'Phone') {
      this.acc.phone = event.target.value;
    }
  }

  handleClick (event) {
    updateAccount ({
      accId: this.recordId,
      acc: JSON.stringify (this.acc),
     
    })
      .then (result => {
        console.log ('Result', result);
      })
      .catch (error => {
        console.error ('Error:', error);
      });
  }
}
